//How to use a module

var circle = require('./circle.js');

var area = circle.area(4);
console.log("----------------------------");
console.log( 'The area of a circle of radius 4 is '+ area);
console.log("----------------------------");

