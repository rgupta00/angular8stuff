
var a = 10;

for(var i=1;i<=5;i++){
    console.log(a + " * " + i + " = " + a*i );
}



